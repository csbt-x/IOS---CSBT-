angular.module("starter").config(function ($stateProvider) {
    $stateProvider.state('bible-view', {
        cache: false,
        url: BASE_PATH + "/bible/mobile_view/index/value_id/:value_id",
        controller: 'BibleController',
        templateUrl: "modules/bible/templates/l1/view.html",
    });
}).controller('BibleController', function ($scope, $stateParams, Url) {
    $scope.is_loading = true;
    $scope.source_id = $stateParams.value_id;
    $scope.value_id = $stateParams.value_id;
    $scope.url = Url.get("bible/mobile_view/find", {
        value_id: $stateParams.value_id
    });
});








